package com.learncodewithsankalp.chatapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatWebApplicationUsingWebsocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatWebApplicationUsingWebsocketApplication.class, args);
	}

}
